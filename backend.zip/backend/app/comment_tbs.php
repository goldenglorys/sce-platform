<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class comment_tbs extends Model
{
    //
}
